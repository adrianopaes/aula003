/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadorajava;

import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class Aula_003 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nome = "";
         nome = JOptionPane.showInputDialog("Po favor digite seu nome");
        String msg = "Bem vindo " + nome + "!";
        JOptionPane.showMessageDialog(null, msg);
        // TODO code application logic here
    }
    
}
